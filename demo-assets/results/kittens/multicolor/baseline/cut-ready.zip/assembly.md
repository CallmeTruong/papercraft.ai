# Assembly guide

Export intent: cut_ready; software status: PASS.
Sheet: 260 × 200 mm.
The file order is FRONT TO BACK. Assemble from the last layer toward the first.
Mask/path fill is retained paper; enclosed holes are removed.
PDF: print at 100% / Actual size; disable fit to page. Verify the 20 mm ruler before cutting.
Black outline: cut. Material SVG fill: keep. Enclosed holes: remove. Keep the entire closed frame.
PDF guide: white material is retained; light diagonal hatch marks waste to REMOVE.
Cut along the solid black contours only; diagonal hatch and gray alignment marks are guides.
CUT SVG/DXF contain cutting paths only. PDFs have no printed text; ruler/alignment marks are guides.
PASS applies to declared continuous software checks. Physical cutting: NOT_RUN.

1. layer-01: #97b44f, spacing 0 mm
2. layer-02: #a4bb71, spacing 0 mm
3. layer-03: #768c46, spacing 0 mm
4. layer-04: #496013, spacing 0 mm
5. layer-05: #415e34, spacing 0 mm
6. layer-06: #c8c5be, spacing 0 mm
7. layer-07: #5f5a58, spacing 0 mm
8. layer-08: #888481, spacing 0 mm
9. layer-09: #272217, spacing 0 mm
10. layer-10: #97b44f, spacing 0 mm
11. layer-11: #a4bb71, spacing 0 mm
12. layer-12: #768c46, spacing 0 mm
13. layer-13: #496013, spacing 0 mm
14. layer-14: #25334c, spacing 0 mm