# Assembly guide

Export intent: cut_ready; software status: PASS.
Sheet: 300 × 230 mm.
The file order is FRONT TO BACK. Assemble from the last layer toward the first.
Mask/path fill is retained paper; enclosed holes are removed.
PDF: print at 100% / Actual size; disable fit to page. Verify the 20 mm ruler before cutting.
Black outline: cut. Material SVG fill: keep. Enclosed holes: remove. Keep the entire closed frame.
PDF guide: white material is retained; light diagonal hatch marks waste to REMOVE.
Cut along the solid black contours only; diagonal hatch and gray alignment marks are guides.
CUT SVG/DXF contain cutting paths only. PDFs have no printed text; ruler/alignment marks are guides.
PASS applies to declared continuous software checks. Physical cutting: NOT_RUN.

1. layer-01: #413913, spacing 3 mm
2. layer-02: #5c4e19, spacing 3 mm
3. layer-03: #2d3e54, spacing 3 mm
4. layer-04: #9fb861, spacing 3 mm
5. layer-05: #a7bd78, spacing 3 mm
6. layer-06: #d4cfc3, spacing 3 mm
7. layer-07: #91b143, spacing 3 mm
8. layer-08: #779347, spacing 3 mm
9. layer-09: #3f5f35, spacing 3 mm
10. layer-10: #0d182d, spacing 3 mm
11. layer-11: #9da2a5, spacing 3 mm
12. layer-12: #65676b, spacing 3 mm
13. layer-13: #8a837d, spacing 3 mm
14. layer-14: #706357, spacing 3 mm
15. layer-15: #4c4643, spacing 3 mm
16. layer-16: #5c4e19, spacing 3 mm
17. layer-17: #9fb861, spacing 3 mm
18. layer-18: #a7bd78, spacing 3 mm
19. layer-19: #d4cfc3, spacing 3 mm
20. layer-20: #1f1d18, spacing 3 mm