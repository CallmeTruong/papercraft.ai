# Broad-area light placement

Coordinates are millimeters from the outer sheet top-left; X right, Y down.
Effective color source is 25 mm behind the rear diffuser.
Additional diffuser spread sigma: 6 mm; angular assumption: 35 degrees.
Exported option: uniform white LED backlight and this broad printed color filter. Keep the filter/source plane behind a neutral spreading layer.
Alternative RGB emitters at the listed centers require a neutral diffuser and separate calibration; do not double-filter their colors.
Intensity is a relative model gain, not electrical power, lux or a calibrated LED setting.
Zone widths below are intrinsic 2-sigma widths before propagation. Physical calibration NOT_RUN.

| Zone | Color | X | Y | Width | Height | Gain |
|---|---|---:|---:|---:|---:|---:|
| zone-01 | #e2d672 | 62.1 | 36.5 | 79.9 | 43.2 | 0.18 |
| zone-02 | #dfff8e | 204.6 | 133.7 | 70.9 | 90.2 | 0.84 |
| zone-03 | #fff9ab | 182.3 | 41.0 | 90.8 | 44.6 | 0.26 |
| zone-04 | #dfff8e | 108.7 | 111.9 | 78.9 | 73.5 | 0.34 |
| zone-05 | #dfff8e | 50.5 | 143.5 | 81.6 | 87.3 | 0.82 |