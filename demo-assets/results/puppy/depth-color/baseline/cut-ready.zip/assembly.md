# Assembly guide

Export intent: cut_ready; software status: PASS.
Sheet: 260 × 182.5 mm.
The file order is FRONT TO BACK. Assemble from the last layer toward the first.
Mask/path fill is retained paper; enclosed holes are removed.
PDF: print at 100% / Actual size; disable fit to page. Verify the 20 mm ruler before cutting.
Black outline: cut. Material SVG fill: keep. Enclosed holes: remove. Keep the entire closed frame.
PDF guide: white material is retained; light diagonal hatch marks waste to REMOVE.
Cut along the solid black contours only; diagonal hatch and gray alignment marks are guides.
CUT SVG/DXF contain cutting paths only. PDFs have no printed text; ruler/alignment marks are guides.
PASS applies to declared continuous software checks. Physical cutting: NOT_RUN.

1. layer-01: #dad1c5, spacing 3 mm
2. layer-02: #beac98, spacing 3 mm
3. layer-03: #8c5939, spacing 3 mm
4. layer-04: #523120, spacing 3 mm
5. layer-05: #241a16, spacing 3 mm
6. layer-06: #b3784f, spacing 3 mm
7. layer-07: #a9886a, spacing 3 mm
8. layer-08: #716356, spacing 3 mm
9. layer-09: #8f423f, spacing 3 mm
10. layer-10: #dad1c5, spacing 3 mm
11. layer-11: #beac98, spacing 3 mm
12. layer-12: #8c5939, spacing 3 mm
13. layer-13: #523120, spacing 3 mm
14. layer-14: #4c474b, spacing 3 mm