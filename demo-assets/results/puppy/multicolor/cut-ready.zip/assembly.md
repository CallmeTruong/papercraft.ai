# Assembly guide

Export intent: cut_ready; software status: PASS.
Sheet: 300 × 209.583 mm.
The file order is FRONT TO BACK. Assemble from the last layer toward the first.
Mask/path fill is retained paper; enclosed holes are removed.
PDF: print at 100% / Actual size; disable fit to page. Verify the 20 mm ruler before cutting.
Black outline: cut. Material SVG fill: keep. Enclosed holes: remove. Keep the entire closed frame.
PDF guide: white material is retained; light diagonal hatch marks waste to REMOVE.
Cut along the solid black contours only; diagonal hatch and gray alignment marks are guides.
CUT SVG/DXF contain cutting paths only. PDFs have no printed text; ruler/alignment marks are guides.
PASS applies to declared continuous software checks. Physical cutting: NOT_RUN.

1. layer-01: #865234, spacing 0 mm
2. layer-02: #b67a4f, spacing 0 mm
3. layer-03: #ad815d, spacing 0 mm
4. layer-04: #e1d9cf, spacing 0 mm
5. layer-05: #a0653f, spacing 0 mm
6. layer-06: #c2b19f, spacing 0 mm
7. layer-07: #b8a08a, spacing 0 mm
8. layer-08: #ac8d71, spacing 0 mm
9. layer-09: #88674b, spacing 0 mm
10. layer-10: #6a4329, spacing 0 mm
11. layer-11: #d0c5b7, spacing 0 mm
12. layer-12: #522e1d, spacing 0 mm
13. layer-13: #94433e, spacing 0 mm
14. layer-14: #71675d, spacing 0 mm
15. layer-15: #41332b, spacing 0 mm
16. layer-16: #865234, spacing 0 mm
17. layer-17: #b67a4f, spacing 0 mm
18. layer-18: #ad815d, spacing 0 mm
19. layer-19: #e1d9cf, spacing 0 mm
20. layer-20: #1d120d, spacing 0 mm