# Broad-area light placement

Coordinates are millimeters from the outer sheet top-left; X right, Y down.
Effective color source is 25 mm behind the rear diffuser.
Additional diffuser spread sigma: 6 mm; angular assumption: 35 degrees.
Exported option: uniform white LED backlight and this broad printed color filter. Keep the filter/source plane behind a neutral spreading layer.
Alternative RGB emitters at the listed centers require a neutral diffuser and separate calibration; do not double-filter their colors.
Intensity is a relative model gain, not electrical power, lux or a calibrated LED setting.
Zone widths below are intrinsic 2-sigma widths before propagation. Physical calibration NOT_RUN.

| Zone | Color | X | Y | Width | Height | Gain |
|---|---|---:|---:|---:|---:|---:|
| zone-01 | #ffb07a | 72.1 | 57.6 | 86.4 | 75.8 | 0.43 |
| zone-02 | #ffd0af | 159.0 | 138.2 | 132.2 | 54.2 | 0.53 |
| zone-03 | #ffb07a | 193.4 | 43.7 | 91.0 | 46.7 | 1.36 |
| zone-04 | #ffd0af | 52.4 | 141.9 | 77.4 | 53.9 | 0.77 |
| zone-05 | #ffd0af | 185.7 | 107.2 | 79.1 | 66.1 | 0.48 |