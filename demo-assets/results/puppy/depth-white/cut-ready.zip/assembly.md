# Assembly guide

Export intent: cut_ready; software status: PASS.
Sheet: 300 × 209.583 mm.
The file order is FRONT TO BACK. Assemble from the last layer toward the first.
Mask/path fill is retained paper; enclosed holes are removed.
PDF: print at 100% / Actual size; disable fit to page. Verify the 20 mm ruler before cutting.
Black outline: cut. Material SVG fill: keep. Enclosed holes: remove. Keep the entire closed frame.
PDF guide: white material is retained; light diagonal hatch marks waste to REMOVE.
Cut along the solid black contours only; diagonal hatch and gray alignment marks are guides.
CUT SVG/DXF contain cutting paths only. PDFs have no printed text; ruler/alignment marks are guides.
PASS applies to declared continuous software checks. Physical cutting: NOT_RUN.

1. layer-01: #ffffff, spacing 4 mm
2. layer-02: #ffffff, spacing 4 mm
3. layer-03: #ffffff, spacing 4 mm
4. layer-04: #ffffff, spacing 4 mm
5. layer-05: #ffffff, spacing 4 mm
6. layer-06: #ffffff, spacing 4 mm
7. layer-07: #ffffff, spacing 4 mm
8. layer-08: #ffffff, spacing 4 mm