# Broad-area light placement

Coordinates are millimeters from the outer sheet top-left; X right, Y down.
Effective color source is 25 mm behind the rear diffuser.
Additional diffuser spread sigma: 6 mm; angular assumption: 35 degrees.
Exported option: uniform white LED backlight and this broad printed color filter. Keep the filter/source plane behind a neutral spreading layer.
Alternative RGB emitters at the listed centers require a neutral diffuser and separate calibration; do not double-filter their colors.
Intensity is a relative model gain, not electrical power, lux or a calibrated LED setting.
Zone widths below are intrinsic 2-sigma widths before propagation. Physical calibration NOT_RUN.

| Zone | Color | X | Y | Width | Height | Gain |
|---|---|---:|---:|---:|---:|---:|
| zone-01 | #e7ff6b | 75.9 | 39.7 | 97.0 | 46.1 | 1.63 |
| zone-02 | #e7ff6b | 187.3 | 128.3 | 88.2 | 53.3 | 1.46 |
| zone-03 | #e7ff6b | 212.5 | 50.1 | 58.1 | 62.3 | 0.24 |
| zone-04 | #e7ff6b | 51.9 | 124.6 | 76.4 | 68.0 | 0.50 |
| zone-05 | #e7ff6b | 121.1 | 85.6 | 84.1 | 71.2 | 0.18 |