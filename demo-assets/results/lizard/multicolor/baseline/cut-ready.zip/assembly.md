# Assembly guide

Export intent: cut_ready; software status: PASS.
Sheet: 260 × 173.75 mm.
The file order is FRONT TO BACK. Assemble from the last layer toward the first.
Mask/path fill is retained paper; enclosed holes are removed.
PDF: print at 100% / Actual size; disable fit to page. Verify the 20 mm ruler before cutting.
Black outline: cut. Material SVG fill: keep. Enclosed holes: remove. Keep the entire closed frame.
PDF guide: white material is retained; light diagonal hatch marks waste to REMOVE.
Cut along the solid black contours only; diagonal hatch and gray alignment marks are guides.
CUT SVG/DXF contain cutting paths only. PDFs have no printed text; ruler/alignment marks are guides.
PASS applies to declared continuous software checks. Physical cutting: NOT_RUN.

1. layer-01: #516718, spacing 0 mm
2. layer-02: #404a19, spacing 0 mm
3. layer-03: #6b5543, spacing 0 mm
4. layer-04: #333427, spacing 0 mm
5. layer-05: #c0d02d, spacing 0 mm
6. layer-06: #aab332, spacing 0 mm
7. layer-07: #778c2d, spacing 0 mm
8. layer-08: #898982, spacing 0 mm
9. layer-09: #d0d178, spacing 0 mm
10. layer-10: #516718, spacing 0 mm
11. layer-11: #404a19, spacing 0 mm
12. layer-12: #6b5543, spacing 0 mm
13. layer-13: #333427, spacing 0 mm
14. layer-14: #88ac75, spacing 0 mm