# Assembly guide

Export intent: cut_ready; software status: PASS.
Sheet: 360 × 237.812 mm.
The file order is FRONT TO BACK. Assemble from the last layer toward the first.
Mask/path fill is retained paper; enclosed holes are removed.
PDF: print at 100% / Actual size; disable fit to page. Verify the 20 mm ruler before cutting.
Black outline: cut. Material SVG fill: keep. Enclosed holes: remove. Keep the entire closed frame.
PDF guide: white material is retained; light diagonal hatch marks waste to REMOVE.
Cut along the solid black contours only; diagonal hatch and gray alignment marks are guides.
CUT SVG/DXF contain cutting paths only. PDFs have no printed text; ruler/alignment marks are guides.
PASS applies to declared continuous software checks. Physical cutting: NOT_RUN.

1. layer-01: #2e3c32, spacing 3 mm
2. layer-02: #664e3e, spacing 3 mm
3. layer-03: #3a4a1e, spacing 3 mm
4. layer-04: #988337, spacing 3 mm
5. layer-05: #514a0e, spacing 3 mm
6. layer-06: #5b7218, spacing 3 mm
7. layer-07: #362a1a, spacing 3 mm
8. layer-08: #c6d62b, spacing 3 mm
9. layer-09: #dedfcd, spacing 3 mm
10. layer-10: #7c9134, spacing 3 mm
11. layer-11: #f0e5c7, spacing 3 mm
12. layer-12: #cfcf64, spacing 3 mm
13. layer-13: #b0be2f, spacing 3 mm
14. layer-14: #d0d094, spacing 3 mm
15. layer-15: #979c25, spacing 3 mm
16. layer-16: #101820, spacing 3 mm
17. layer-17: #661c1a, spacing 3 mm
18. layer-18: #2e3c32, spacing 3 mm
19. layer-19: #664e3e, spacing 3 mm
20. layer-20: #3a4a1e, spacing 3 mm
21. layer-21: #988337, spacing 3 mm
22. layer-22: #514a0e, spacing 3 mm
23. layer-23: #5b7218, spacing 3 mm
24. layer-24: #8b211d, spacing 3 mm